import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FaqComponent } from './faq/faq.component';
import { LoginComponent } from './login/login.component';
import { ReqSurveyComponent } from './req-survey/req-survey.component';
import { SearchComponent } from './search/search.component';

const routes: Routes = [{
  path: 'login' , 
  component: LoginComponent
},
{
  path: 'search', 
  component: SearchComponent
},
{
  path: 'reqSurvey', 
  component: ReqSurveyComponent
},
{
  path: 'dashboard', 
  component: DashboardComponent
},
{
  path: 'faq', 
  component: FaqComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
