import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-connection-info',
  templateUrl: './connection-info.component.html',
  styleUrls: ['./connection-info.component.css']
})

export class ConnectionInfoComponent implements OnInit {
  buttonToggle = true;

  constructor() { }

  ngOnInit(): void {
  }

}
