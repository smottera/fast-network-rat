import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-propertyviewer',
  templateUrl: './propertyviewer.component.html',
  styleUrls: ['./propertyviewer.component.css']
})
export class PropertyviewerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
